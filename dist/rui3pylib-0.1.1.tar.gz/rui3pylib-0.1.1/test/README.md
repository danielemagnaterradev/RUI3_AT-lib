# rui3pylib — Test Suite

Test suite completa per la libreria Python `rui3pylib`, wrapper AT-command
per i moduli RAKwireless RUI3 (RAK3172, RAK4630, RAK11720, ecc.).

---

## Struttura del progetto

```
rui3pylib_tests/           ← rootdir (da qui si lancia pytest)
├── pytest.ini             # Configurazione pytest, markers, pythonpath
├── rui3pylib.py           # Libreria sotto test
└── tests/                 # NESSUN __init__.py — pytest rootdir-style
    ├── conftest.py         # Fixture condivise, FakeSerial, costanti
    ├── test_connection.py
    ├── test_core_functions.py
    ├── test_general_commands.py
    ├── test_low_power.py
    ├── test_serial_commands.py
    ├── test_bootloader.py
    ├── test_lorawan_keys.py
    ├── test_lorawan_join_send.py
    ├── test_lorawan_network_mgmt.py
    ├── test_class_b_info_regional_multicast.py
    ├── test_p2p.py
    └── test_rf_test.py
```

> **Importante**: la cartella `tests/` NON deve contenere `__init__.py`.
> Con `__init__.py` presente Python tratta `tests/` come package e
> l'import `from conftest import ...` fallisce con `ModuleNotFoundError`.
> Senza `__init__.py`, pytest aggiunge `tests/` a `sys.path` in automatico
> e l'import funziona correttamente.

---

## Installazione e avvio rapido

```bash
# 1. Installa le dipendenze (una sola volta)
pip install pytest pyserial

# 2. Entra nella directory del progetto
cd rui3pylib_tests

# 3. Esegui tutta la suite
pytest
```

Output atteso con la versione corrente della libreria:
```
567 passed, 0 warnings   (tutti i test, incluso il @bug che documenta BUG-001)
```

---

## Copertura

| Metrica                           | Valore       |
|-----------------------------------|--------------|
| Metodi pubblici `RUI3Node`        | 183 / 183    |
| Copertura metodi                  | **100 %**    |
| Test totali                       | **567**      |
| Test class                        | 113          |
| File di test                      | 12           |

---

## Architettura del mock

Tutti i test unitari evitano completamente l'I/O seriale reale.
Le due uniche funzioni che toccano il cavo (`send_command` e
`check_success`) vengono sostituite con `unittest.mock.patch` in ogni
singolo test.

```python
# Pattern standard usato in ogni test
with patch("rui3pylib.check_success", return_value=("\r\nOK\r\n", True)) as m:
    result = node.some_method(valid_value)
    m.assert_called_once_with(node, "AT+CMD=valid_value")
    assert result is not None
```

La fixture `node` (in `conftest.py`) restituisce un'istanza di
`_TestNode`, una sottoclasse di `RUI3Node` che sovrascrive `__init__`
con un no-op: nessuna porta seriale reale o virtuale è richiesta.

`FakeSerial` è usata **solo** in `test_core_functions.py` per testare
le primitive I/O al livello byte.

---

## Comandi pytest utili

```bash
# Tutta la suite
pytest

# Pre-release: tutto tranne il bug noto documentato
pytest -m "not bug" --tb=short

# Solo una categoria
pytest -m lorawan
pytest -m p2p
pytest -m boundary
pytest -m cmd_format

# Critico per certificazioni (boundary + validation)
pytest -m "validation or boundary" -v

# Solo un file
pytest tests/test_lorawan_keys.py -v

# Verifica che il bug noto sia ancora presente
pytest -m bug -v
```

---

## Marker personalizzati

| Marker         | Descrizione                                                   | N. test |
|----------------|---------------------------------------------------------------|---------|
| `boundary`     | Valori al limite, appena dentro, appena fuori                 | 207     |
| `cmd_format`   | Verifica la stringa AT esatta inviata al device               | 183     |
| `validation`   | Logica di validazione input / guard clause                    | 170     |
| `lorawan`      | Comandi specifici LoRaWAN                                     | 134     |
| `p2p`          | Comandi P2P / FSK                                             | 119     |
| `happy_path`   | Comportamento nominale con input valido                       | 90      |
| `rf_test`      | Comandi di test RF e certificazione                           | 68      |
| `device_error` | Device risponde con AT_PARAM_ERROR / AT_BUSY_ERROR / ecc.     | 57      |
| `bootloader`   | Comandi che operano solo in boot mode                         | 12      |
| `bug`          | Bug noto documentato nell'implementazione corrente            | 1       |

---

## Bug documentati

### BUG-001 — `set_p2p_params()` default `bandwidth=125` viola il guard 0–9

**File**: `tests/test_p2p.py::TestP2pParams::test_BUG001_default_bandwidth_125_fails_guard`
**Marker**: `@pytest.mark.bug`
**Stato**: OPEN
**Impatto**: ALTO — chiamare `set_p2p_params()` senza argomenti fallisce silenziosamente

**Causa**: il parametro è definito come `bandwidth: int = 125` (il valore
in kHz) ma il guard interno verifica `0 <= bandwidth <= 9` (l'indice
AT+P2P, dove 0 = 125 kHz).

**Fix**:
```python
# PRIMA (errato)
def set_p2p_params(self, ..., bandwidth: int = 125, ...):

# DOPO (corretto)
def set_p2p_params(self, ..., bandwidth: int = 0, ...):
```

Il test `test_BUG001_...` passa con il comportamento rotto attuale e
**fallirà automaticamente quando il bug verrà corretto**, segnalando
che la regressione è stata risolta.

---

## Note su comandi speciali

### ATZ / AT+LOCK / AT+BOOT (fire-and-forget)
Usano `send_command` direttamente perché il device non risponde con `OK`.
I test verificano che `check_success` **non** venga mai chiamata.

### `try_connect()` — unico metodo che ritorna `bool`
- Usa `check_success` con `wait=5.0` (timeout esteso per avvio lento)
- Cattura `serial.serialutil.PortNotOpenError` → restituisce `False`
- Non propaga mai eccezioni

### AT+TCONF — coding rate 1-based
AT+TCONF usa `cr` con base 1 (1=4/5 … 4=4/8), diversamente da AT+PCR
(0-based). I test in `test_rf_test.py` verificano che `cr=0` venga
rifiutato.

### AT+PRECV — valori speciali del timeout

| Valore  | Comportamento                                     |
|---------|---------------------------------------------------|
| 0       | Ferma RX, passa a TX                              |
| 1–65532 | RX per *timeout* ms, poi auto-stop                |
| 65533   | RX continua, TX ancora permesso                   |
| 65534   | RX continua, TX bloccato fino a `PRECV=0`         |
| 65535   | RX finché ricevuto 1 pacchetto, poi torna a TX    |
